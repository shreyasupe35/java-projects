/**
 * 
 */
/**
 * @author supes
 *
 */
module intern {
}