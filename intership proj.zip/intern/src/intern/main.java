package intern;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.*;

public class main {
	
	static String passw;
	static File file = new File("list.txt");
	static File file2 = new File("list2.txt");
	public static boolean
    isValidPassword(String password)
    {
 
        // Regex to check valid password.
        String regex = "^(?=.*[0-9])"
                       + "(?=.*[a-z])(?=.*[A-Z])"
                       + "(?=.*[@#$%^&+=])"
                       + "(?=\\S+$).{8,20}$";
 
        // Compile the ReGex
        Pattern p = Pattern.compile(regex);
  
        // If the password is empty
        // return false
        if (password == null) {
            return false;
        }
 
        // Pattern class contains matcher() method
        // to find matching between given password
        // and regular expression.
        Matcher m = p.matcher(password);
 
        // Return if the password
        // matched the ReGex
        return m.matches();
    }
 
	
	
	
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		School s=new School();
		SStudent ss=new SStudent();
		teachers tt=new teachers();
		int fl=1;
		System.out.println("Hi");
		System.out.println("welcome to Bangalore institute of technology");
		System.out.println("enter the password");
		passw=sc.nextLine();
		if(isValidPassword(passw)) {
		while(fl==1) {
		System.out.println("Login as \n 1.Admin \n 2.Student \n3.Faculty\n");
		int ch=sc.nextInt();
		if(ch==1)s. Admin();
		else if(ch==2)ss.Student();
		else tt.Faculty();
		System.out.println("do you want to continue y/n=0");
		if(fl==0) {
			exit(0);
		}
	
		}}
		else{
			System.out.println("invalid password");
		}
		
	}




	private static void exit(int i) {
		// TODO Auto-generated method stub
		
	}
}
