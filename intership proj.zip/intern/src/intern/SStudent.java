package intern;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class SStudent extends main {
	public static void Student() {
		String id3;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the id");
		id3=sc.next();
	    Scanner scanner;
		try {
	        scanner = new Scanner(file);

	        while (scanner.hasNext()) {
	             String lineFromFile = scanner.nextLine();
	             String[] arrOfStr = lineFromFile.split(" ");
	            if (arrOfStr[0].equals(id3)) {
	            	System.out.println("id\t\tname\t\ttotal fees\t\tremaining fees");
	            	System.out.println(lineFromFile);
	            	arrOfStr=null;
	                break;
	            }
	           
	        }
	    } catch (IOException e) {
	        System.out.println(" please enter  a valid id");
	    }
		
	}

}
