package intern;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class teachers extends main {

	public static void Faculty() {
		String id2;
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the id");
		id2=sc.nextLine();
	    Scanner scanner2;
		try {
	        scanner2 = new Scanner(file2);

	        while (scanner2.hasNext()) {
	            String lineFromFile = scanner2.nextLine();
	            String[] arrOfStr = lineFromFile.split(" ");
	            if (arrOfStr[0].equals(id2)) {
	            System.out.println("id\t\tname\t\t\ttotal salary\t\tremainingsalary ");
	            System.out.println(lineFromFile);
	            arrOfStr=null;
                break;
            }
        
	        }
	    } catch (IOException e) {
	        System.out.println(" please enter  a valid id");
	    }
	}

	
	}

	

