package intern;
import java.util.Scanner;
import java.io.*;
public class School extends main {

	
	public static void replaceSelected(String replaceWith, String type,String f) throws IOException {
		
		
		 String filePath =f+ ".txt";
		 Scanner sc = new Scanner(new File(filePath));
		 StringBuffer buffer = new StringBuffer();
		 while (sc.hasNextLine()) {
	         buffer.append(sc.nextLine()+System.lineSeparator());
	      }
		 String fileContents = buffer.toString();
		 sc.close();
		 fileContents = fileContents.replaceAll(replaceWith, type);
		 FileWriter writer = new FileWriter(filePath);
		 writer.append(fileContents);
		 writer.flush();
		 
	}
	
	
	
	public static void Admin() throws IOException {
		Scanner sc=new Scanner(System.in);
		String id;
		System.out.println("Enter the id");
		id=sc.next();
		
		String st;
		if(id.equals("79750")){
			System.out.println("Do you want to 1.read\n2.update");
			int c=sc.nextInt() ;
			sc.nextLine();
			if(c==1) {
			BufferedReader br
	        = new BufferedReader(new FileReader(file));
			BufferedReader br2
	        = new BufferedReader(new FileReader(file2));
			try {
				System.out.println("Student details");
				System.out.println();
				System.out.println("id\t\tname\t\ttotal fees\tremaining fees");
				while ((st = br.readLine()) != null)
				    System.out.println(st);
				System.out.println("\n\n");
				System.out.println("Faculty details");
				System.out.println();
				System.out.println("id\t\tname\t\t\ttotal salary\t\tremainingsalary ");
				while((st=br2.readLine())!=null)
					System.out.println(st);
				
				br2.close();
				br.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			}
			else{
				
				System.out.println("enter the file name");
				String f=sc.nextLine();
				System.out.println("enter the details that u want to upadate");
				System.out.println();
				String replaceWith=sc.nextLine();
				System.out.println("enter the updation value");
				String type=sc.nextLine();
				replaceSelected(replaceWith,type,f);   
			}
		}
	    
		else {
			System.out.println("Invalid id");
		}
		}
}
