package intern;

public interface MyFilenameFilter {

}
